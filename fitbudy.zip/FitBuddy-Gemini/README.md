# FitBuddy – AI Fitness Plan Generator using Gemini Models

FitBuddy is a web-based AI fitness assistant that generates personalized 7-day workout plans and nutrition/recovery tips from user inputs such as age, weight, fitness goal, and workout intensity. Users can submit feedback to regenerate an updated plan. An admin view displays registered users and their original/updated plans.

## Stack
- Frontend: HTML, CSS, Jinja2
- Backend: FastAPI
- AI: Google Gemini API
- Database: SQLite + SQLAlchemy
- Server: Uvicorn
- Language: Python

## Setup
```bash
python -m venv venv
# Windows: venv\\Scripts\\activate
# Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000` and `/docs`.

Set your own Gemini key in `.env`. Never upload `.env` or a real key to GitHub.

If the key is absent, FitBuddy runs in clearly marked demo mode so the full interface/database flow can still be demonstrated.

The eight required SmartBridge phases are in `docs/`.
