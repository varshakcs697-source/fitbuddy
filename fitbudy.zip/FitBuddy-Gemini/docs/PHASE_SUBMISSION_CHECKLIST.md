# Final GitHub Checklist

- [ ] 8 SmartBridge phase folders completed
- [ ] Team/member/faculty details added
- [ ] Screenshots added
- [ ] Public GitHub repository verified
- [ ] `.env` is NOT uploaded
- [ ] Gemini API key is NOT uploaded
- [ ] Demo video uploaded to Google Drive
- [ ] Drive permission: Anyone with the link / Viewer
