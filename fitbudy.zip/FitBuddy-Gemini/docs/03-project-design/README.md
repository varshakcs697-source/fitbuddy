# Phase 3 – Project Design

```text
Browser -> FastAPI/Jinja2 -> Gemini Workout -> 7-Day Plan
                         -> Gemini Flash -> Nutrition Tip
                         -> SQLAlchemy -> SQLite
Feedback -> Gemini Workout -> Updated Plan
Admin -> Users / Original Plan / Updated Plan
```

## Modules
- `main.py`: application entry point
- `routes.py`: routing and processing
- `database.py`: SQLAlchemy/SQLite
- `gemini_generator.py`: workout generation
- `gemini_flash_generator.py`: nutrition tip
- `updated_plan.py`: feedback revision
- `templates/`: UI pages
