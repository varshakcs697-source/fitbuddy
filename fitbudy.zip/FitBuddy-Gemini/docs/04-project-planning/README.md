# Phase 4 – Project Planning

| Milestone | Work | Deliverable |
|---|---|---|
| 1 | Model, architecture, environment | Design + setup |
| 2 | Core AI/database functions | Backend |
| 3 | FastAPI routes | End-to-end flow |
| 4 | HTML/CSS/Jinja2 | UI |
| 5 | Local deployment/testing | Verified app |

Suggested 4-member roles: backend/database, AI integration, frontend, testing/documentation/demo.
