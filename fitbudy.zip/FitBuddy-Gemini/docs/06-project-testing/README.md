# Phase 6 – Project Testing

| Test | Expected |
|---|---|
| Home page | Loads successfully |
| Valid profile | Plan + tip displayed |
| Invalid age/weight | Validation error |
| New User ID | Record created |
| Existing User ID | Record updated |
| Feedback | Updated plan stored |
| Unknown feedback ID | Error shown |
| Admin view | Users/plans visible |
| Delete user | Record removed |
| /docs | Swagger UI loads |
| No API key | Demo mode works |

Add screenshots to this folder before final GitHub submission.
