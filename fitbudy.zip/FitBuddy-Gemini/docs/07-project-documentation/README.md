# Phase 7 – Project Documentation

**Title:** FitBuddy – AI Fitness Plan Generator using Gemini Models

**Purpose:** Demonstrate an AI-powered web application that creates personalized 7-day workout plans, nutrition/recovery tips and adaptive revisions.

**Stack:** Python, FastAPI, Jinja2, HTML/CSS/JavaScript, Google Gemini, SQLAlchemy, SQLite, Uvicorn.

**Security:** `.env` is ignored by Git. Never upload a real Gemini API key. The demo admin page should receive authentication before real-world deployment.

**Limitation:** Educational guidance only; not a medical/clinical system.
