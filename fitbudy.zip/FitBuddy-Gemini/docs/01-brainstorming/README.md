# Phase 1 – Brainstorming & Ideation

## Problem
Users may need a structured fitness routine that considers their goal, profile and preferred intensity.

## Idea
FitBuddy accepts name, user ID, age, weight, fitness goal and workout intensity, then generates a 7-day plan, a nutrition/recovery tip and a feedback-based revision.

## Scenarios
1. Generate a new plan.
2. Revise an existing plan using feedback.
3. Generate a nutrition/recovery tip.
4. Let an admin/coach review users and plans.
