# Phase 8 – Project Demonstration

## Suggested demo order
1. Introduce FitBuddy, its purpose and benefits.
2. Show the technology stack.
3. Enter sample user data and generate a 7-day plan.
4. Show the nutrition/recovery tip.
5. Submit feedback such as “Add more cardio and include an additional recovery day.”
6. Show the updated plan and confirmation.
7. Open `/view-all-users` and show stored records.
8. Open `/docs` and show FastAPI Swagger.
9. Close with the final output and use case.

## Submission placeholders
- Public GitHub URL: ADD HERE
- Google Drive demo URL: ADD HERE
- Team members: ADD HERE
- College/class: ADD HERE
- Faculty/HOD: ADD HERE
