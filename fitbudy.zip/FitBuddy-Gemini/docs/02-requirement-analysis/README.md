# Phase 2 – Requirement Analysis

## Functional requirements
- Accept user profile information.
- Generate a structured 7-day workout plan.
- Generate a nutrition/recovery tip.
- Store users and plans in SQLite.
- Accept feedback and generate an updated plan.
- Preserve original and updated versions.
- Provide an admin view.
- Provide FastAPI API documentation.

## Non-functional requirements
Responsive UI, modular Python code, environment-variable API credentials, validation, error handling and local Uvicorn deployment.

## Inputs
Name, User ID, age, weight, goal and intensity.

## Outputs
Workout plan, nutrition/recovery tip and revised plan.
