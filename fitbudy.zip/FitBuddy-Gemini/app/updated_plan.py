import os
from dotenv import load_dotenv
load_dotenv()
try:
    import google.generativeai as genai
except ImportError:
    genai = None
def update_workout_plan(original_plan: str, feedback: str, goal: str, intensity: str) -> str:
    key = os.getenv("GOOGLE_API_KEY")
    if not key or genai is None:
        return f"{original_plan}\n\n--- UPDATED USING FEEDBACK ---\nGoal: {goal} | Intensity: {intensity}\nRequested change: {feedback}\nDemo mode note: Add GOOGLE_API_KEY to let Gemini regenerate the complete plan."
    genai.configure(api_key=key)
    model = genai.GenerativeModel(os.getenv("GEMINI_WORKOUT_MODEL", "gemini-1.5-pro"))
    prompt = f'''Revise this 7-day workout plan using the feedback.
Goal: {goal}
Intensity: {intensity}
Original plan:
{original_plan}
Feedback:
{feedback}
Return a complete revised 7-day plan with warm-up, main workout and cooldown/recovery. Do not make medical claims.'''
    return model.generate_content(prompt).text.strip()
