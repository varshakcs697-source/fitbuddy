import os
from dotenv import load_dotenv
load_dotenv()
try:
    import google.generativeai as genai
except ImportError:
    genai = None
DEMO_TIPS = {
    "weight loss": "Prioritize balanced meals, adequate protein and fiber, hydration, and sustainable portions rather than extreme restriction.",
    "muscle gain": "Include a protein source in each main meal and pair resistance training with adequate food, hydration, and recovery.",
    "general wellness": "Build a consistent routine around balanced meals, hydration, regular movement, quality sleep, and recovery.",
}
def generate_nutrition_tip_with_flash(goal: str) -> str:
    key = os.getenv("GOOGLE_API_KEY")
    if not key or genai is None:
        return DEMO_TIPS.get(goal.lower().strip(), "Stay hydrated and prioritize balanced meals with protein, vegetables, whole grains, and adequate recovery.")
    genai.configure(api_key=key)
    model = genai.GenerativeModel(os.getenv("GEMINI_TIP_MODEL", "gemini-1.5-flash"))
    prompt = f"Give one concise, practical nutrition or recovery tip for fitness goal: {goal}. Keep it general and educational; do not prescribe a medical diet."
    return model.generate_content(prompt).text.strip()
