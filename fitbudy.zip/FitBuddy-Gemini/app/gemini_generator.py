import os
from dotenv import load_dotenv
load_dotenv()
try:
    import google.generativeai as genai
except ImportError:
    genai = None

DEMO_PLAN = '''7-DAY DEMO WORKOUT PLAN

Day 1 – Full Body
Warm-up: 8 minutes brisk walking and mobility.
Main workout: Bodyweight squats 3x12, incline push-ups 3x10, glute bridges 3x12, plank 3x30 sec.
Cooldown: 5 minutes gentle stretching.

Day 2 – Cardio
Warm-up: 5 minutes easy walking.
Main workout: 25 minutes moderate walking/cycling with short faster intervals.
Cooldown: 5 minutes slow walking and stretching.

Day 3 – Upper Body
Warm-up: 7 minutes shoulder and arm mobility.
Main workout: Incline push-ups 3x10, resistance rows 3x12, shoulder raises 2x12, dead bug 3x10.
Cooldown: Upper-body stretching.

Day 4 – Recovery
Easy walking for 20–30 minutes plus gentle mobility and breathing exercises.

Day 5 – Lower Body
Warm-up: 8 minutes walking and leg mobility.
Main workout: Squats 3x12, reverse lunges 3x8 each side, calf raises 3x15, glute bridges 3x12.
Cooldown: Lower-body stretching.

Day 6 – Core + Cardio
Warm-up: 5 minutes easy movement.
Main workout: 20 minutes cardio plus bird-dog 3x10, plank 3x30 sec, dead bug 3x10.
Cooldown: Gentle stretching.

Day 7 – Rest / Active Recovery
Easy walk and light stretching as comfortable.

General note: Start gradually, use controlled form, rest when needed, and stop if an exercise causes pain.'''

def _model():
    key = os.getenv("GOOGLE_API_KEY")
    if not key or genai is None:
        return None
    genai.configure(api_key=key)
    return genai.GenerativeModel(os.getenv("GEMINI_WORKOUT_MODEL", "gemini-1.5-pro"))

def generate_workout_gemini(goal: str, intensity: str, age: int, weight: float) -> str:
    model = _model()
    if model is None:
        return DEMO_PLAN + "\n\n[Demo mode: configure GOOGLE_API_KEY for Gemini generation.]"
    prompt = f'''Create a structured 7-day general fitness workout plan.
Age: {age}
Weight: {weight} kg
Goal: {goal}
Intensity: {intensity}
Include Day 1–Day 7, warm-up, main workout with sets/reps or duration, and cooldown/recovery. Keep it practical and educational. Avoid diagnosis or medical claims and add a short safety note.'''
    return model.generate_content(prompt).text.strip()
