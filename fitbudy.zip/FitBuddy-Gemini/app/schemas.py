from pydantic import BaseModel, Field
class UserInput(BaseModel):
    user_id: str = Field(min_length=1, max_length=80)
    username: str = Field(min_length=1, max_length=120)
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, lt=400)
    goal: str = Field(min_length=2, max_length=120)
    intensity: str
class FeedbackRequest(BaseModel):
    user_id: str
    feedback: str = Field(min_length=2, max_length=2000)
