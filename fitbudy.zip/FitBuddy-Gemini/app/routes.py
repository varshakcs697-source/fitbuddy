from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from .database import SessionLocal, User
from .gemini_generator import generate_workout_gemini
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .updated_plan import update_workout_plan
router = APIRouter()
templates = Jinja2Templates(directory="templates")
@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "error": None})
@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(request: Request, username: str = Form(...), user_id: str = Form(...), age: int = Form(...), weight: float = Form(...), goal: str = Form(...), intensity: str = Form(...)):
    if not 13 <= age <= 100 or not 20 < weight < 400:
        return templates.TemplateResponse("index.html", {"request": request, "error": "Please enter a valid age and weight."}, status_code=400)
    try:
        plan = generate_workout_gemini(goal, intensity, age, weight)
        tip = generate_nutrition_tip_with_flash(goal)
        db = SessionLocal()
        user = db.query(User).filter(User.user_id == user_id.strip()).first()
        if user:
            user.username = username.strip(); user.age = age; user.weight = weight; user.goal = goal.strip(); user.intensity = intensity.strip(); user.original_plan = plan; user.updated_plan = None; user.nutrition_tip = tip
        else:
            user = User(user_id=user_id.strip(), username=username.strip(), age=age, weight=weight, goal=goal.strip(), intensity=intensity.strip(), original_plan=plan, nutrition_tip=tip)
            db.add(user)
        db.commit(); db.close()
        return templates.TemplateResponse("result.html", {"request": request, "user": user, "workout_plan": plan, "nutrition_tip": tip, "message": None})
    except Exception as exc:
        return templates.TemplateResponse("index.html", {"request": request, "error": f"Unable to generate the plan: {exc}"}, status_code=500)
@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: str = Form(...), feedback: str = Form(...)):
    db = SessionLocal(); user = db.query(User).filter(User.user_id == user_id.strip()).first()
    if not user:
        db.close(); return templates.TemplateResponse("index.html", {"request": request, "error": "User ID not found. Generate a plan first."}, status_code=404)
    base = user.updated_plan or user.original_plan or ""
    try:
        revised = update_workout_plan(base, feedback, user.goal, user.intensity)
        user.updated_plan = revised; db.commit()
        return templates.TemplateResponse("result.html", {"request": request, "user": user, "workout_plan": revised, "nutrition_tip": user.nutrition_tip, "message": "Your plan has been updated based on your feedback!"})
    except Exception as exc:
        return templates.TemplateResponse("result.html", {"request": request, "user": user, "workout_plan": base, "nutrition_tip": user.nutrition_tip, "message": f"Update failed: {exc}"}, status_code=500)
    finally:
        db.close()
@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request):
    db = SessionLocal(); users = db.query(User).order_by(User.id.desc()).all(); db.close()
    return templates.TemplateResponse("all_users.html", {"request": request, "users": users})
@router.post("/delete-user/{user_id}")
def delete_user(user_id: str):
    db = SessionLocal(); user = db.query(User).filter(User.user_id == user_id).first()
    if user: db.delete(user); db.commit()
    db.close(); return RedirectResponse(url="/view-all-users", status_code=303)
