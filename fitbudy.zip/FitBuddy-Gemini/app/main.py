from fastapi import FastAPI
from .database import init_db
from .routes import router
app = FastAPI(title="FitBuddy – AI Fitness Plan Generator", description="FastAPI + Gemini + SQLite fitness planning application.", version="1.0.0")
init_db()
app.include_router(router)
